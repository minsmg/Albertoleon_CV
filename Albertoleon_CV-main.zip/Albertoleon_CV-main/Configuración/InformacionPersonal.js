<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Currículum de Alberto León</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9fafc;
      color: #333;
      scroll-behavior: smooth;
      transition: background 0.5s, color 0.5s;
    }
    header {
      background: linear-gradient(135deg, #1abc9c, #16a085);
      color: white;
      text-align: center;
      padding: 2rem 1rem;
    }
    header img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      margin-bottom: 1rem;
      border: 3px solid #fff;
    }
    nav {
      background-color: #2c3e50;
      text-align: center;
      padding: 0.8rem;
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    nav a {
      color: #ecf0f1;
      margin: 0 15px;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s;
    }
    nav a:hover {
      color: #1abc9c;
    }
    nav a.active {
      color: #1abc9c;
      font-weight: 700;
      border-bottom: 2px solid #1abc9c;
    }
    section {
      max-width: 900px;
      margin: 2rem auto;
      padding: 1.5rem;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: background 0.5s, color 0.5s;
    }
    h2 {
      font-weight: 600;
      margin-bottom: 1rem;
    }
    ul {
      list-style: none;
      padding: 0;
    }
    ul li {
      margin: 0.8rem 0;
      line-height: 1.6;
    }
    .perfil h2 { color: #1abc9c; }
    .experiencia h2 { color: #3498db; }
    .educacion h2 { color: #2ecc71; }
    .habilidades h2 { color: #e67e22; }
    .proyectos h2 { color: #9b59b6; }

    /* Animación fade-in */
    .fade-in {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 1s ease-out, transform 1s ease-out;
    }
    .fade-in.visible {
      opacity: 1;
      transform: translateY(0);
    }

    /* Botón flotante volver arriba */
    #btnTop {
      display: none;
      position: fixed;
      bottom: 30px;
      right: 30px;
      z-index: 1000;
      background-color: #1abc9c;
      color: white;
      border: none;
      padding: 12px 18px;
      border-radius: 50px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background 0.3s;
    }
    #btnTop:hover {
      background-color: #16a085;
    }

    /* Botón modo oscuro */
    #btnDark {
      position: fixed;
      bottom: 30px;
      left: 30px;
      z-index: 1000;
      background-color: #2c3e50;
      color: white;
      border: none;
      padding: 12px 18px;
      border-radius: 50px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background 0.3s;
    }
    #btnDark:hover {
      background-color: #1abc9c;
    }

    /* Estilos modo oscuro */
    body.dark {
      background-color: #121212;
      color: #f1f1f1;
    }
    body.dark section {
      background-color: #1e1e1e;
      color: #f1f1f1;
      box-shadow: 0 4px 10px rgba(255,255,255,0.1);
    }
    body.dark nav {
      background-color: #111;
    }
    body.dark nav a {
      color: #ddd;
    }
    body.dark nav a.active {
      color: #1abc9c;
      border-bottom: 2px solid #1abc9c;
    }
    body.dark footer {
      background-color: #111;
      color: #ddd;
    }
    footer {
      background-color: #2c3e50;
      color: #ecf0f1;
      text-align: center;
      padding: 1rem;
      margin-top: 2rem;
      font-size: 0.9rem;
    }
    footer p {
      margin: 0.3rem 0;
    }
  </style>
</head>
<body>
  <header>
    <img src="tu-foto.jpg" alt="Foto de Alberto León">
    <h1>Alberto León</h1>
    <p>Técnico Superior en Producción Industrial | Gestión de Calidad y Seguridad</p>
    <p>📧 tuemail@correo.com | 🔗 linkedin.com/in/tuusuario | 💻 github.com/minsmg</p>
  </header>

  <!-- Menú de navegación -->
  <nav>
    <a href="#perfil">Perfil</a>
    <a href="#experiencia">Experiencia</a>
    <a href="#educacion">Educación</a>
    <a href="#habilidades">Habilidades</a>
    <a href="#proyectos">Proyectos</a>
  </nav>

  <section id="perfil" class="perfil fade-in">
    <h2>👤 Perfil Profesional</h2>
    <p>Técnico Superior en Producción Industrial con más de 30 años de experiencia en procesos industriales,
    control de calidad y seguridad laboral. Apasionado por la mejora continua, el liderazgo
    organizacional y la formación multidisciplinaria. Mi objetivo es aportar soluciones
    innovadoras que optimicen la productividad y garanticen ambientes de trabajo seguros.
    Me caracterizo por un enfoque ético y humanista, respaldado por mi formación en teología,
    lo que me permite integrar valores sólidos en la gestión empresarial.</p>
  </section>

  <section id="experiencia" class="experiencia fade-in">
    <h2>🧑‍💼 Experiencia</h2>
    <ul>
      <li><strong>Supervisor de Calidad – Empresa X (2015–2023)</strong><br>
        Implementación de ISO 9001, reducción de fallas en procesos en un 20%, optimización de procedimientos de control de calidad.</li>
      <li><strong>Coordinador de Seguridad – Empresa Y (2000–2015)</strong><br>
        Programas de seguridad industrial certificados, capacitación de personal en protocolos de seguridad, reducción de incidentes laborales.</li>
    </ul>
  </section>

  <section id="educacion" class="educacion fade-in">
    <h2>🎓 Educación y Certificaciones</h2>
    <ul>
      <li>Diplomado en Gestión de Calidad ISO 9001 – Politécnico Superior de Colombia (2023)</li>
      <li>Certificación en Lean Manufacturing</li>
      <li>Curso de Inglés Intermedio – 2023</li>
      <li>Licenciatura en Teología – 1990</li>
    </ul>
  </section>

  <section id="habilidades" class="habilidades fade-in">
    <h2>⚙️ Habilidades Técnicas</h2>
    <ul>
      <li>Control de Calidad (25 años)</li>
      <li>Seguridad Industrial (20 años)</li>
      <li>Excel y herramientas digitales (15 años)</li>
      <li>PLC, Scada, Instrumentación</li>
      <li>Inglés intermedio</li>
    </ul>
  </section>

  <section id="proyectos" class="proyectos fade-in">
    <h2>📂 Proyectos Destacados</h2>
    <ul>
      <li>Manual de Seguridad Industrial</li>
      <li>Informe de Mejora Continua</li>
      <li>Dashboard de Control de Calidad en Excel</li>
      <li>Simulación de Procesos
